#include <iostream>
#include <sstream>
#include <algorithm>

using namespace std;

int main() {
#ifdef LOCAL
  freopen("tennis.in", "r", stdin);
  freopen("tennis.out", "w", stdout);
#else
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
#endif
  int n, i, j;
  while (cin >> n >> i >> j) {
    if (i > j) swap(i, j);
    
    int mi = (i+1) / 2;
    int mj = (j+1) / 2;
    i = mi;
    j = mj;

    int ans = 1;
    while (i != j) {
      mi = (i+1) / 2;
      mj = (j+1) / 2;
      
      i = mi;
      j = mj;
      ans++;
    }

    
    cout << ans << '\n';
  }

  return 0;
}
