#include <bits/stdc++.h>

using namespace std;

const int maxn = 1010;
const double PI = acos(-1.0);
const double EPS = 1e-6;

struct point {
  long long x, y;
  point(long long x = 0, long long y = 0) :
    x(x), y(y) { }
} P[maxn];

struct vec {
  double x, y;
  vec(double x = 0, double y = 0) :
    x(x), y(y) { }
  void normalize() {
    double norm = sqrt(x*x + y*y);
    x = x / norm;
    y = y / norm;
  }
};

long long cross(point p, point q, point r) {
  return (r.x - q.x) * (p.y - q.y) - (r.y - q.y) * (p.x - q.x);
}

bool collinear(point p, point q, point r) {
  return abs(cross(p,q,r)) == 0;
}

// angulo entre 2 vectores
double ang(vec u, vec v) {
  u.normalize();
  v.normalize();
  double cosalpha = (u.x * v.x + u.y * v.y); // / (sqrt(u.x * u.x + u.y * u.y) * sqrt(v.x * v.x + v.y * v.y));
  double sinalpha = (u.x * v.y - u.y * v.x);
  //cout << "alpha => " << alpha << endl;
  double x = atan2(sinalpha, cosalpha);

  return x;
}

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  
  int N;
  while (cin >> N) {
	if (N == 0) break;

    for (int i = 0; i < N; i++) {
       long long x, y;
       cin >> x >> y;
       P[i] = point(x,y);
	}
	P[N] = P[0];
	P[N+1] = P[1];
	
	int ans = 0;
	double sum = 0;
	for (int i = 1; i <= N; i++) {
	  //cout << "cross => " << cross(P[i-1], P[i], P[i+1]) << '\n';
	  vec u(P[i].x - P[i-1].x, P[i].y - P[i-1].y);
	  vec v(P[i+1].x - P[i].x, P[i+1].y - P[i].y);

	  double a = ang(u, v);
	  //assert(2*PI-a > -EPS);
	  //if (cross(P[i-1], P[i], P[i+1]) < 0)
	  //cout << "a => " << (a * 180. / PI) << endl;
	  //a = fabs(a);
	  if (a < 0)
	    a += 2*PI;
	  sum += a;
	}
	sum = sum / (2*PI);
	assert(!isnan(sum));
	//cout << "sum => " << sum << '\n';
	ans = (int)floor(sum+EPS);
	cout << ans << '\n';
  }
  
  return 0;
}
