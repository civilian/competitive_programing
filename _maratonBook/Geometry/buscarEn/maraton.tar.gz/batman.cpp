#include <bits/stdc++.h>
#include <tr1/unordered_map>
#include <tr1/unordered_set>

#define foreach(it,v) for (__typeof((v).begin()) it=(v).begin(); it!=(v).end(); it++)

using namespace std;

const long long INF = (long long)1e18;
const int maxn = 1010;

int P, V, E, cost[maxn], ofense[maxn], defense[maxn];
string powers[maxn], villans[maxn];
std::tr1::unordered_set<string> affects[maxn];
std::tr1::unordered_map<string, int> M;

//long long 
//int memo[maxn][maxn];
map<int, int> memo[maxn][maxn];

void add(int k, string s) {
  int n = s.size();
  for (int i = 0; i < n; i++) {
     string t;
     while (i < n && s[i] != ',')
       t.push_back(s[i++]);
     int j = M[t];
     if (ofense[j] >= defense[k])
	   affects[k].insert(t);
  }
}

//long long 
bool dp(int v, int j, int e) { // v => villano, j => ultimo poder usado [1;P]
  if (e < 0) return false;
  if (v == V && e >= 0) return true;
  if (j == P) return false;
  
  if (memo[v][j].count(e))
    return memo[v][j][e];

  //long long res = INF;
  bool res = false;
  foreach(it, affects[v]) {
    int k = M[*it];
    if (k > j) {
      //res = min(res, cost[k] + dp(v+1, k));
      res |= dp(v+1, k, e-cost[k]);
      if (res) break;
	}
  }
  return memo[v][j][e] = res;
}

bool solve() {
  for (int i = 0; i <= V; i++)
    for (int j = 0; j <= P; j++)
      memo[i][j].clear();
  //memset(memo, -1, sizeof memo);
  //long long ans = dp(0, 0);
  //return ans <= E;
  return dp(0,0,E);
}

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  
  while (cin >> P >> V >> E) {
	if ((P|V|E) == 0)
	  break;
	M.clear();
    for (int i = 0; i < P; i++) {
	  cin >> powers[i+1] >> ofense[i+1] >> cost[i+1];
	  M[powers[i+1]] = i+1;
    }

	for (int i = 0; i < V; i++) {
      affects[i].clear();
      string s;
      cin >> villans[i] >> defense[i] >> s;
      add(i, s);
	}
	
	cout << (solve()? "Yes" : "No") << '\n';
  }
  
  return 0;
}
